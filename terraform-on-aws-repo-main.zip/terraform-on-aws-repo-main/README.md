# terraform-on-aws-repo
Sample Terraform files to create S3 bucket in AWS
